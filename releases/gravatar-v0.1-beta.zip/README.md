# Gravatar

Gravatar is a small library  for interfacing with **gravatar**

## Installation

Via Composer

``` bash
$ composer require gravatarphp/gravatar
```
